package com.example.myassssmentapplication

data class LoginResponse(
    val keypass: String
)


